
public class DivideIntegers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		double ratio = 3/5;
		double castedRatio = (double) 3/5;
		
		System.out.println(3/5);
		System.out.println(ratio);
		System.out.println(castedRatio);
		
		System.out.println( (3 + 0.5) / (5 + 10 * 0.5) );
		
	}

}
