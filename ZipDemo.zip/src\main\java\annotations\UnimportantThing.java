package annotations;

public class UnimportantThing {
}
