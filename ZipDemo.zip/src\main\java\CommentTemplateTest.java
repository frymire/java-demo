// UNCLASSIFIED

/**
 *<p>This is a test to see if my code template works.<p>
 *
 * (C) Copyright DECISIVE ANALYTICS Corporation 2016<br>
 * All Rights Reserved <br>
 * DAC Proprietary <br>
 *
 * @author mark.e.frymire
 *
 */
public class CommentTemplateTest {
	
	public static void main(String[] args) {
		System.out.println("hi.");		
	}	
	
}