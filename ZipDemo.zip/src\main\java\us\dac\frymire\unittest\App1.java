
package us.dac.frymire.unittest;

/**
 * This is a class with a main method used to greet somebody.
 *
 */
public class App1 
{
	/**
	 * Greets somebody.
	 * 
	 * @param args
	 */
    public static void main( String[] args )
    {
        System.out.println( "Suck it hard." );
    }
}
