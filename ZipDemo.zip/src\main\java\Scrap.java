
public class Scrap {
  
  public static void main(String[] args) {
    String theString = "Hey, how are you doing?";
    System.out.println(theString.replace(",", ""));
  }
}
